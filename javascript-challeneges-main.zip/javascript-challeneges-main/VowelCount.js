//my soultion
function solution(str){
  const arr=str.split("");
  const reversed= arr.reverse();
  const finalAnswer=reversed.join("");
  
return finalAnswer;
}

//bestsoultion
function getCount(str) {
  return (str.match(/[aeiou]/ig)||[]).length;
}
