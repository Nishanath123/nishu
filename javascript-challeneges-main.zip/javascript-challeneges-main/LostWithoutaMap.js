function maps(arr){
  
  const result = arr.map((arrItem) => {
    return arrItem * 2;
  });
  
  return result;
}
