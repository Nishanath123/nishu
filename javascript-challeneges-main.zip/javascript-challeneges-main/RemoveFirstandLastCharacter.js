function removeChar(str){
  return str.substring(1, str.length-1);
};
