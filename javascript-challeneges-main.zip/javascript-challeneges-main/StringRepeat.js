function stringToArray(string){

  return string.split(" ");

}
