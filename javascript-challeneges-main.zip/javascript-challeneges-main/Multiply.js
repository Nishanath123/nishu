multiply = function (a, b) {
  return a * b;
}
